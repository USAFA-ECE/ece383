To use this component:

1. Add the vhd files to your project.
2. Copy the Component Declaration from the included txt file into the declarative section of your Lab2 architecture
3. Copy the Component Instantiation from the included txt file into the body of your Lab2 architecture
4. Uncomment the OLED Display lines in the constraints file

